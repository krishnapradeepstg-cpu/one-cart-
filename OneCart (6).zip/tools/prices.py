#!/usr/bin/env python3
"""
One Cart - price sheet tool
===========================
Lets a shop (or you) give REAL prices, MRPs and stock, so the app can show real
"% OFF" badges and "out of stock" labels. Nothing is invented: a discount only
appears when a row has an MRP higher than the selling price.

  1) python tools/prices.py export          -> writes tools/prices.csv (open in Excel / Google Sheets)
  2) edit these columns:  price, mrp, in_stock   (leave the other columns alone)
        price     the selling price in rupees (required)
        mrp       the printed MRP on the pack (leave blank if unknown)
        in_stock  yes or no
  3) python tools/prices.py apply           -> checks every row, then updates catalog.js

Safety checks (a bad row is skipped and reported, never half-applied):
  - price must be a number above 0
  - mrp must be blank or NOT lower than price (selling above MRP is not allowed in India)
  - in_stock must be yes or no
  - unknown product ids are ignored
A backup copy catalog.js.bak is made before anything is changed.
If your admin panel also sets prices, those admin prices override this file in the live app.
"""
import csv, json, re, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CAT = ROOT / "catalog.js"
CSV = ROOT / "tools" / "prices.csv"
PAT = re.compile(r"const CATALOG=(\[.*?\]);", re.S)


def read():
    text = CAT.read_text(encoding="utf-8")
    m = PAT.search(text)
    return text, m, json.loads(m.group(1))


def export():
    _, _, cat = read()
    with open(CSV, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["id", "category", "name", "pack", "price", "mrp", "in_stock"])
        for p in cat:
            w.writerow([p["id"], p["c"], p["n"], p.get("u", ""), p["p"], p.get("mrp", ""),
                        "no" if p.get("out") else "yes"])
    print(f"Wrote {CSV} with {len(cat)} products. Edit price, mrp, in_stock, then run: apply")


def apply():
    if not CSV.exists():
        sys.exit("tools/prices.csv not found. Run: python tools/prices.py export")
    text, m, cat = read()
    by_id = {p["id"]: p for p in cat}
    changed, errors = 0, []
    with open(CSV, newline="", encoding="utf-8-sig") as f:
        for n, r in enumerate(csv.DictReader(f), start=2):
            p = by_id.get(r["id"].strip())
            if not p:
                continue
            try:
                price = float(r["price"])
                if price <= 0:
                    raise ValueError("price must be above 0")
                price = int(price) if price == int(price) else round(price, 2)
                mrp_s = (r.get("mrp") or "").strip()
                mrp = None
                if mrp_s:
                    mrp = float(mrp_s)
                    mrp = int(mrp) if mrp == int(mrp) else round(mrp, 2)
                    if mrp < price:
                        raise ValueError(f"MRP {mrp} is lower than price {price}")
                stock = (r.get("in_stock") or "yes").strip().lower()
                if stock not in ("yes", "no"):
                    raise ValueError("in_stock must be yes or no")
            except ValueError as e:
                errors.append(f"row {n} ({r['id']}): {e}")
                continue
            before = (p["p"], p.get("mrp"), bool(p.get("out")))
            p["p"] = price
            if mrp is not None and mrp > price:
                p["mrp"] = mrp
            else:
                p.pop("mrp", None)
            if stock == "no":
                p["out"] = 1
            else:
                p.pop("out", None)
            if before != (p["p"], p.get("mrp"), bool(p.get("out"))):
                changed += 1
    if errors:
        print("These rows were skipped:")
        for e in errors:
            print("  ", e)
    shutil.copyfile(CAT, str(CAT) + ".bak")
    new = "const CATALOG=" + json.dumps(cat, ensure_ascii=False, separators=(",", ":")) + ";"
    CAT.write_text(text[:m.start()] + new + text[m.end():], encoding="utf-8")
    print(f"Updated {changed} products ({len(errors)} rows skipped). Backup: catalog.js.bak")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    {"export": export, "apply": apply}.get(cmd, lambda: sys.exit(__doc__))()
