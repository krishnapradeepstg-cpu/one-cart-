#!/usr/bin/env python3
"""
One Cart - product photo importer
=================================
Adds REAL product photos to the app without ever guessing silently.

  1) python tools/import_images.py fetch      -> looks products up on Open Food Facts,
                                                  downloads the best candidate photo,
                                                  writes tools/matches.csv + tools/review.html
  2) (you) open tools/review.html, check each photo, then edit tools/matches.csv:
          set approve = yes (keep) or no (reject)  -- only "yes" rows are used
  3) python tools/import_images.py build      -> converts approved photos (+ your own photos in
                                                  tools/incoming/) to small WebP files in img/p/
                                                  and writes product-images.js

Your own photos: put files in tools/incoming/ named  <group-id>.jpg  (or .png/.webp).
Group ids are in tools/products.csv (column "group"). One photo is used for every pack size
of that product. Your own photos always win over Open Food Facts photos.

Requirements:  pip install pillow requests
Open Food Facts asks for polite use: this script waits between searches (default 7 s) and
remembers results in tools/cache/, so you can stop and resume any time.
Photos from Open Food Facts are CC BY-SA 4.0; the app shows that credit on the product page.
"""
import argparse, csv, html, io, json, re, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOOLS = ROOT / "tools"
CACHE = TOOLS / "cache"
CAND = TOOLS / "candidates"
INCOMING = TOOLS / "incoming"
OUT_IMG = ROOT / "img" / "p"
MANIFEST = ROOT / "product-images.js"

# Which categories to look up, and which database serves them.
FOOD = ["staples", "dals", "oils", "masala", "dairy", "bakery", "biscuits", "snacks", "breakfast",
        "instant", "bev", "teacoffee", "choc", "frozen", "dryfruits", "baby"]
BEAUTY = ["pcare"]
HOSTS = {"food": "https://world.openfoodfacts.org", "beauty": "https://world.openbeautyfacts.org"}
STOP = {"the", "and", "with", "of", "in", "for", "pack", "combo", "fresh", "regular", "premium", "new"}
AUTO_APPROVE = 0.80   # score at/above this is pre-marked "yes"; you still review everything
MIN_KEEP = 0.50       # below this the candidate is not even downloaded


def load_catalog():
    text = (ROOT / "catalog.js").read_text(encoding="utf-8")
    text = re.sub(r"^/\*.*?\*/\s*", "", text, flags=re.S)
    return json.loads(re.search(r"const CATALOG=(\[.*?\]);", text, re.S).group(1))


def groups(catalog, cats):
    g = {}
    for p in catalog:
        if p["c"] not in cats:
            continue
        k = p.get("g") or p["id"]
        e = g.setdefault(k, {"group": k, "name": p["n"], "cat": p["c"], "ids": [], "units": []})
        e["ids"].append(p["id"])
        e["units"].append(p.get("u", ""))
    return g


def tokens(s):
    s = s.lower().replace("&", " ")
    return [t for t in re.findall(r"[a-z0-9]+", s) if t not in STOP and (len(t) > 2 or t.isdigit())]


def to_base(q):
    """'500 g' / '1.5 kg' / '2 L' -> (amount, 'g'|'ml')"""
    m = re.search(r"([\d.]+)\s*(kg|g|gm|l|ltr|ml)\b", (q or "").lower())
    if not m:
        return None
    n, u = float(m.group(1)), m.group(2)
    return {"kg": (n * 1000, "g"), "g": (n, "g"), "gm": (n, "g"), "l": (n * 1000, "ml"),
            "ltr": (n * 1000, "ml"), "ml": (n, "ml")}[u]


def score(ours_name, units, cand):
    ours = set(tokens(ours_name))
    if not ours:
        return 0.0
    hay = set(tokens((cand.get("brands") or "") + " " + (cand.get("product_name") or "")))
    s = len(ours & hay) / len(ours)
    first = tokens(ours_name)[0]          # usually the brand (Fortune, India Gate, Aashirvaad...)
    if first not in hay:                  # photo of another brand = wrong product, never accept
        return min(s, 0.45)
    cq = to_base(cand.get("quantity", ""))
    if cq and any(to_base(u) == cq for u in units):
        s = min(1.0, s + 0.1)          # pack size agrees
    return round(s, 2)


def search(host, query, ua, cache):
    key = host + "|" + query
    if key in cache:
        return cache[key], False
    import requests
    r = requests.get(host + "/cgi/search.pl", timeout=40, headers={"User-Agent": ua}, params={
        "search_terms": query, "search_simple": 1, "action": "process", "json": 1, "page_size": 8,
        "fields": "code,product_name,brands,quantity,image_front_url"})
    r.raise_for_status()
    data = r.json().get("products", [])
    cache[key] = data
    return data, True


def cmd_fetch(a):
    import requests
    CACHE.mkdir(parents=True, exist_ok=True); CAND.mkdir(parents=True, exist_ok=True)
    cf = CACHE / "search.json"
    cache = json.loads(cf.read_text(encoding="utf-8")) if cf.exists() else {}
    cats = [c for c in (a.categories.split(",") if a.categories else FOOD + BEAUTY)]
    cat = load_catalog()
    G = groups(cat, set(cats))
    # products.csv = every group, so you can find the ids for your own photos
    with open(TOOLS / "products.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["group", "category", "name", "pack_sizes", "product_ids"])
        for e in G.values():
            w.writerow([e["group"], e["cat"], e["name"], " | ".join(e["units"]), " ".join(e["ids"])])
    host_for = lambda c: a.host or (HOSTS["beauty"] if c in BEAUTY else HOSTS["food"])
    rows, n = [], 0
    for e in G.values():
        n += 1
        if a.limit and n > a.limit:
            break
        host = host_for(e["cat"])
        try:
            res, live = search(host, e["name"], a.user_agent, cache)
        except Exception as ex:
            print(f"[{n}/{len(G)}] {e['name']}: search failed ({ex})"); continue
        if live:
            cf.write_text(json.dumps(cache), encoding="utf-8"); time.sleep(a.delay)
        best = None
        for c in res:
            if not c.get("image_front_url"):
                continue
            sc = score(e["name"], e["units"], c)
            if not best or sc > best[0]:
                best = (sc, c)
        if not best or best[0] < MIN_KEEP:
            print(f"[{n}/{len(G)}] {e['name']}: no good match"); continue
        sc, c = best
        img = CAND / (e["group"] + ".jpg")
        if not img.exists():
            try:
                r = requests.get(c["image_front_url"], timeout=40, headers={"User-Agent": a.user_agent})
                r.raise_for_status(); img.write_bytes(r.content)
            except Exception as ex:
                print(f"[{n}/{len(G)}] {e['name']}: image download failed ({ex})"); continue
        rows.append({"group": e["group"], "our_name": e["name"], "pack_sizes": " | ".join(e["units"]),
                     "found_name": c.get("product_name", ""), "found_brand": c.get("brands", ""),
                     "found_pack": c.get("quantity", ""), "score": sc, "barcode": c.get("code", ""),
                     "approve": "yes" if sc >= AUTO_APPROVE else "no"})
        print(f"[{n}/{len(G)}] {e['name']}  ->  {c.get('brands','')} {c.get('product_name','')}  (score {sc})")
    cols = ["group", "our_name", "pack_sizes", "found_name", "found_brand", "found_pack", "score", "barcode", "approve"]
    with open(TOOLS / "matches.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, cols); w.writeheader(); w.writerows(rows)
    review(rows)
    print(f"\nDone. {len(rows)} candidates. Open tools/review.html, then edit tools/matches.csv (approve = yes/no).")


def review(rows):
    h = ["<meta charset=utf-8><title>One Cart photo review</title><style>body{font-family:system-ui;margin:20px}"
         "table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:8px;vertical-align:middle}"
         "img{width:110px;height:110px;object-fit:contain;background:#fafafa}.y{background:#e8f7ec}.n{background:#fff1f1}</style>"
         "<h2>Check each row: does the photo show the SAME product as 'Our product'?</h2>"
         "<p>Set <b>approve</b> to yes/no in <code>tools/matches.csv</code>. Wrong brand, wrong flavour or wrong product = no.</p><table>"
         "<tr><th>Photo</th><th>Our product</th><th>Found on Open Food Facts</th><th>Score</th><th>approve</th></tr>"]
    for r in rows:
        cls = "y" if r["approve"] == "yes" else "n"
        h.append(f"<tr class={cls}><td><img src='candidates/{html.escape(r['group'])}.jpg'></td>"
                 f"<td><b>{html.escape(r['our_name'])}</b><br>{html.escape(r['pack_sizes'])}<br><small>{html.escape(r['group'])}</small></td>"
                 f"<td>{html.escape(r['found_brand'])} {html.escape(r['found_name'])}<br>{html.escape(r['found_pack'])}</td>"
                 f"<td>{r['score']}</td><td>{r['approve']}</td></tr>")
    h.append("</table>")
    (TOOLS / "review.html").write_text("\n".join(h), encoding="utf-8")


def process(src_bytes, dest):
    from PIL import Image
    im = Image.open(io.BytesIO(src_bytes))
    if im.mode in ("RGBA", "LA", "P"):
        im = im.convert("RGBA"); bg = Image.new("RGB", im.size, "white"); bg.paste(im, mask=im.split()[-1]); im = bg
    else:
        im = im.convert("RGB")
    im.thumbnail((600, 600))
    canvas = Image.new("RGB", (600, 600), "white")
    canvas.paste(im, ((600 - im.width) // 2, (600 - im.height) // 2))
    dest.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(dest, "WEBP", quality=82, method=6)


def cmd_build(a):
    cat = load_catalog()
    ids_by_group = {}
    for p in cat:
        ids_by_group.setdefault(p.get("g") or p["id"], []).append(p["id"])
    all_ids = {p["id"] for p in cat}
    manifest, used = {}, {}
    mf = TOOLS / "matches.csv"
    if mf.exists():
        for r in csv.DictReader(open(mf, encoding="utf-8")):
            if r["approve"].strip().lower() != "yes":
                continue
            src = CAND / (r["group"] + ".jpg")
            if not src.exists():
                print("missing candidate photo for", r["group"]); continue
            process(src.read_bytes(), OUT_IMG / (r["group"] + ".webp"))
            for i in ids_by_group.get(r["group"], []):
                manifest[i] = ["img/p/" + r["group"] + ".webp", "off"]
            used[r["group"]] = "off"
    own = 0
    if INCOMING.exists():
        for f in sorted(INCOMING.iterdir()):
            if f.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp"):
                continue
            key = f.stem
            ids = ids_by_group.get(key) or ([key] if key in all_ids else [])
            if not ids:
                print("skipped (no product with this id):", f.name); continue
            gname = key if key in ids_by_group else key
            process(f.read_bytes(), OUT_IMG / (gname + ".webp"))
            for i in ids:
                manifest[i] = ["img/p/" + gname + ".webp", "own"]
            used[key] = "own"; own += 1
    MANIFEST.write_text("/* Generated by tools/import_images.py. Maps product id -> [image path, source]. */\nvar PRODUCT_IMG="
                        + json.dumps(manifest, separators=(",", ":")) + ";\n", encoding="utf-8")
    print(f"Done: {len(used)} products with photos ({own} of your own), {len(manifest)} pack sizes covered.")
    print("Upload img/p/ and product-images.js together with the app.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("fetch")
    f.add_argument("--categories", help="comma list, e.g. staples,dals (default: all packaged-food + beauty)")
    f.add_argument("--limit", type=int, help="only the first N products (for a test run)")
    f.add_argument("--delay", type=float, default=7.0, help="seconds between searches (default 7)")
    f.add_argument("--host", help="override database host (testing)")
    f.add_argument("--user-agent", default="OneCartApp/2.0 (contact: your-email@example.com)",
                   help="put your real contact email here, Open Food Facts asks for it")
    sub.add_parser("build")
    a = ap.parse_args()
    {"fetch": cmd_fetch, "build": cmd_build}[a.cmd](a)


if __name__ == "__main__":
    main()
