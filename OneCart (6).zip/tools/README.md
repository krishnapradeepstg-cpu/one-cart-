# Adding real product photos to One Cart

Run these on your own computer (needs internet and Python 3). One time setup:

    pip install pillow requests

## Option A - photos from Open Food Facts (free, packaged food)
1. Open `tools/import_images.py`, find `--user-agent` and put your real email in the default (they ask for it).
2. `python tools/import_images.py fetch`
   It searches each product, waits 7 seconds between searches (their rule), and can be stopped and resumed.
   Expect several hours for the whole catalogue; try `--categories staples --limit 20` first.
3. Open `tools/review.html`. For each row, ask: is the photo the SAME brand and product?
   Then edit `tools/matches.csv` and set `approve` to `yes` or `no`. Only `yes` rows are used.
4. `python tools/import_images.py build`
5. Upload the new `img/p/` folder and `product-images.js` with the rest of the app.

Fresh vegetables and fruit are not in Open Food Facts; they keep their current stock photos.
Photos from Open Food Facts are CC BY-SA 4.0. The app shows that credit on the product page.

## Option B - your own photos (best quality, and what BigBasket/Blinkit really do)
Photograph each pack on a plain white background, then put the files in `tools/incoming/`
named after the product group id (see `tools/products.csv`, column `group`), e.g.
`groc-aashirvaad-shudh-chakki-atta.jpg`. Run `build` (step 4). Your photos always win.
You can also get brand-approved pack photos from the brands or your distributors.

## Rules that keep it safe
- A photo is never used unless it was approved (Option A) or you supplied it (Option B).
- If a photo file is missing or fails to load, the app shows the product icon, never a broken image.

---

# Real prices, MRPs and stock (for shops)

Discount badges ("14% OFF") and "Out of stock" labels only appear when a shop gives real numbers.

1. `python tools/prices.py export`   -> creates `tools/prices.csv` (open in Excel or Google Sheets)
2. Edit only `price`, `mrp` and `in_stock` (yes/no). Leave `mrp` blank if you don't know it.
3. `python tools/prices.py apply`    -> checks every row and updates `catalog.js`

Rules enforced: price must be a number above 0, MRP can never be lower than the price, in_stock must be yes or no.
Bad rows are skipped and listed; good rows are still applied. A backup `catalog.js.bak` is made first.
If your admin panel also sets a price, the admin price wins in the live app.
