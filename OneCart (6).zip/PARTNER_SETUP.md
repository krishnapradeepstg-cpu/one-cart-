# One Cart Delivery Partner - setup guide

Partner app :  https://bespoke-beijinho-b0559d.netlify.app/partner.html   (the old /rider.html link redirects here)
Staff app   :  https://bespoke-beijinho-b0559d.netlify.app/admin.html

## Do these 4 steps once
1. **Upload everything in the zip to Netlify** (new files: `partner.html`, `partner.webmanifest`, `staff-config.js`,
   `admin.webmanifest`). The staff page you see online will not change until you do this.
2. **Add the partner database rules** from `FIRESTORE_RULES_PARTNERS.txt` (Firebase console > Firestore > Rules).
   READ THE NOTES IN THAT FILE. Test in the Rules playground before publishing. This step protects PAN and bank
   details so only you and the partner can read them. Without it the partner app shows "permission-denied".
3. Optional: put your mobile number in `staff-config.js` (`SUPPORT_PHONE`) so partners see a "Call One Cart" button.
4. You (the owner) open the partner link once with your owner Gmail: it skips ID checks, so you can test as a partner.

## What a partner must provide (based on the Blinkit list you gave me)
Age 18+, two-wheeler (a bicycle is also allowed here), smartphone with internet and location, Aadhaar (last 4 digits saved),
PAN, driving licence number and expiry, vehicle registration number, RC holder name, vehicle insurance (company, policy number,
expiry), address proof type, bank account and IFSC, emergency contact, and preferred hours (4, 8 or 10 hours a day) and
time of day. I have not verified Blinkit's current requirements myself.

## Terms shown to applicants (you decide, I did not copy any of Blinkit's)
Open `staff-config.js` > `PARTNER_TERMS` and fill only what is TRUE for your business, for example
`payout:'Weekly, every Monday'`. Empty lines are hidden. Please do not promise earnings or insurance you do not provide.
Be careful with a joining fee: ask a lawyer first, some states regulate fees charged to gig workers.

## Expiry control
Licence and insurance expiry dates are tracked. Partners get a warning 30 days before; on the day after expiry they cannot
go online. You see the same flags on the Partners tab. To let them update a renewed document, tap Reject on their profile
with the note "Please update your insurance", and they can edit and submit again.

## How a delivery partner joins
1. Opens the partner link on their phone > Continue with Google > Start application.
2. Five steps: Personal details > Vehicle and licence > Aadhaar and PAN > Bank account > Review and submit.
   Every field is checked (age 18+, valid Aadhaar, PAN, IFSC, vehicle number, licence and insurance not expired, account numbers match).
3. They see "Application under review" and cannot go online yet.
4. You open the **Staff app > Partners** tab. Pending applications are at the top. Tap **Review application**.
   PAN, licence and account numbers are hidden until you tap Show. Tick the verification checks (identity, licence, RC and insurance, address proof, bank), then **Approve**
   (or Reject with a reason the partner sees, so they can fix it and apply again). You can also Pause a partner later.
5. The partner's phone updates by itself. They can now go online and receive orders.

## IMPORTANT - about the ID details
- **Aadhaar:** the app checks the 12-digit number is valid but saves ONLY THE LAST 4 DIGITS. Indian rules restrict private
  businesses from collecting and storing full Aadhaar numbers. If you need Aadhaar verified, use a licensed verification
  service (for example DigiLocker-based or an ID-check provider). Ask your CA or a lawyer what you may keep.
- **PAN, licence number and bank account** are saved, but readable only by you (owner) and the partner. Google encrypts the
  database at rest. Never share a screenshot of the Partners page.
- **Nothing is verified automatically.** The app only checks the format. YOU must confirm that the documents are real and
  belong to the person (by seeing the originals, calling them, or using a verification service) before you tick the checks.
- **Not included yet:** photo or document uploads (needs Firebase Storage and its own rules), police or background-check
  integration, bank "penny-drop" verification, insurance, training, and a payout/earnings system.
- Please ask a lawyer about: the partner agreement and terms (the app only has tick-boxes and your privacy policy), the
  India data protection law (consent, how long you keep the data, deleting it when a partner leaves), and whether partners are
  employees or independent contractors. To delete a partner's data, delete their `riders` and `riderKyc` documents in the
  Firebase console.

## Dispatch (unchanged)
Nearest approved partner within 5 km gets the ring for 20 seconds, then the next one, then any approved partner within 15 km
for 30 seconds. Only one can accept. Unapproved or paused partners are never offered orders.
Limits: the ring works while the app is open and the screen is on; a locked phone needs push notifications (separate build).

## Staff app (admin.html)
Install it like an app (Android: Install app button; iPhone: Share > Add to Home Screen). Tabs: Orders, Partners, Products,
Customers, Stats. Orders can be searched, WhatsApped, cancelled with a reason, or re-dispatched. Products have MRP and
In stock / Out of stock. Stats can be downloaded as CSV.
