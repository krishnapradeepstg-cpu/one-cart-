# Rider dispatch - setup (do these 5 steps once)

Your rider page:  https://bespoke-beijinho-b0559d.netlify.app/rider.html
Your staff page:  https://bespoke-beijinho-b0559d.netlify.app/admin.html

## 1. Add each rider's Gmail in `staff-config.js`
    RIDERS:['rider1@gmail.com','rider2@gmail.com'],

## 2. Add the SAME Gmail addresses to your Firestore rules
Firebase console > Firestore Database > Rules. Add the rider emails to your existing `staff()` list.
(I cannot see your rules, so I could not do this for you. Without it the page shows "permission-denied".)

## 3. Add this rule for the new `riders` collection (inside `match /databases/{database}/documents`)
    match /riders/{uid} {
      allow read: if staff();
      allow write: if staff() && request.auth.uid == uid;
    }
If your staff check has a different function name, use that name instead of `staff()`.

## 4. Upload to Netlify (same place as the app)
Upload EVERYTHING in the zip, not just some files. New files: `rider.html`, `staff-config.js`, `admin.webmanifest`, `rider.webmanifest`.
The old staff page you see online will not change until you do this.

## 5. Rider's first time
Open the rider link on the phone > Sign in with Google > Me tab > save name and 10-digit mobile >
Home tab > switch ON "Online" and allow Location. Keep the screen on and the volume up.

## How a new order is dispatched
1. The order is offered to the nearest online rider within 5 km. That phone rings and vibrates for 20 seconds.
2. If the rider declines or does not answer, the next nearest rider gets it for 20 seconds, and so on.
3. If nobody nearby accepts, any online rider within 15 km can take it for 30 seconds.
4. Only one rider can accept; a rider who is too late is told so. The customer app then shows that rider's name and phone.
5. The rider shops, enters the actual bill, taps Start delivery (live location is shared), and finishes with the customer's 4-digit PIN.
The numbers (5 km, 20 s, 15 km, 30 s) are at the top of the script in `rider.html` (`CFG`).

## Important limits (please read)
- The ring works only while the rider page is open and the phone screen is on. The page asks the phone to stay awake
  while online, but if the rider locks the phone or switches apps, the sound may NOT play. Reliable "wake the phone"
  alerts need push notifications (Firebase Cloud Messaging plus a small server function). That is a separate build.
- iPhone Safari does not vibrate, and may block sound until the rider has tapped the screen. Android Chrome works best.
- Distance is a straight line, not road distance.
- Not tested against your real Firebase project or rules, only against a simulated database.


---

# Staff app (admin.html) - what is new

Open https://bespoke-beijinho-b0559d.netlify.app/admin.html on your phone and tap **Install app**
(Android Chrome). On iPhone: Share button > Add to Home Screen. It then opens like a normal app with a bottom tab bar.

- **Orders:** search by order number, name or phone; filter All / Today / Yesterday / 7 days; WhatsApp the customer;
  Cancel with a reason (saved, and the customer sees "Order cancelled"); Re-dispatch a shopping order to nearby riders again.
- **Riders:** who is online, last seen, active orders.
- **Products:** set MRP (must not be below the price) and mark items In stock / Out of stock.
  Customers see the real "% OFF" and "Out of stock" straight away, and cannot order an out-of-stock item.
- **Customers:** everyone who ordered, repeat customers, call or WhatsApp.
- **Stats:** Today / 7 days / all loaded; orders, delivered value, delivery fees, average order, cancelled %, orders by hour,
  most ordered items; **Download orders (CSV)** for your accountant.
Orders and stats use the latest 200 orders.
