/* One Cart staff settings - the ONE place to list staff Gmail addresses.
   OWNERS: full access (orders, products, riders, stats).  RIDERS: delivery partners (use rider.html).
   IMPORTANT: every address here must ALSO be added to the Firestore rules staff() list, or the page cannot read orders. */
var STAFF_CONFIG={
 OWNERS:['krishnapradeepstg@gmail.com'],
 RIDERS:[],
 FIREBASE:{apiKey:"AIzaSyAObYK5Y7QQG2tMSgjoFwho5fPqN-t_nMw",authDomain:"repalle-now.firebaseapp.com",projectId:"repalle-now",storageBucket:"repalle-now.firebasestorage.app",messagingSenderId:"442025517640",appId:"1:442025517640:web:3450a3fb0353348945ee7d"}
};
